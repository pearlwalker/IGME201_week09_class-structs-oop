﻿using System;

namespace IGME201_week09_class_structs_oop
{
    //Character class
    public class Character
    {
        public string name;
        public int exp = 0;

        //Reset(); //If I actually wanted to call private method

        public Character() //basic Character constructor
        { name = "Not assigned"; }
        public Character(string name) //name Character constructor
        { this.name = name; }

        //Method: print Name + EXP
        public virtual void PrintStatsInfo() 
        { Console.WriteLine("Hero: " + this.name + " - " + this.exp + " EXP"); }
        
        //Encapsulation: Reset method
        private void Reset()
        {
            this.name = "Not assigned";
            this.exp = 0;
        }

    }

    //Child class: Paladin
    public class Paladin: Character
    {
        public Weapon weapon;

        public Paladin(string name, Weapon weapon): base(name)
        {
            //base keyword calls parent constructor
            this.weapon = weapon;
        }
        public override void PrintStatsInfo()
        {
            Console.WriteLine("Hail " + this.name + " - take up your " + this.weapon.name + "!");
        }
    }

    //Struct: Weapon
    public struct Weapon
    {
        public string name;
        public int damage;

        //Constructor w Name + Damage params
        public Weapon(string name, int damage)
        {
            this.name = name;
            this.damage = damage;
        }
        
        //Method: print Name + Damage
        public void PrintWeaponStats()
        {
            Console.WriteLine("Weapon: " + this.name + " - " + this.damage + " DMG");
        }
    }
    internal class Program
    {
        static void Main(string[] args)
        {
            //Declare default Character instance
            Character hero = new Character();
                //Console.WriteLine("Hero: " + hero.name + " - " + hero.exp + " EXP");
            hero.PrintStatsInfo();
            
            //Declare Character instance that's a girl
            Character heroine = new Character("Agatha");
                //Console.WriteLine("Hero: " + heroine.name + " - " + heroine.exp + " EXP");
            heroine.PrintStatsInfo();

            //New Weapon
            Weapon huntingBow = new Weapon("Hunting Bow", 105);
            huntingBow.PrintWeaponStats();


            //Testing reference types
            Character villain = hero;

            //Test: Output should be identical
            hero.PrintStatsInfo();
            villain.PrintStatsInfo();

            villain.name = "Sir Kane the Brave";

            //Test: Output should be identical w new name
            hero.PrintStatsInfo();
            villain.PrintStatsInfo();


            //Testing value types
            Weapon warBow = huntingBow; //huntingBow declared above

            //Test: Output should be identical
            huntingBow.PrintWeaponStats();
            warBow.PrintWeaponStats();

            warBow.name = "War Bow";
            warBow.damage = 155;

            //Test: Output is now different
            huntingBow.PrintWeaponStats();
            warBow.PrintWeaponStats();


            //Encapsulation
            //hero.Reset(); //doesn't work bc private method needs to be called within class


            //Inheritance + Composition
            Paladin knight = new Paladin("Sir Arthur", huntingBow);
            knight.PrintStatsInfo();


            //Testing external files
            Adventurer mike = new Adventurer("Mike");
            mike.PrintStatsInfo();

            Dude dave = new Dude("Dave");
            dave.PrintStatsInfo();

        }
    }
    }